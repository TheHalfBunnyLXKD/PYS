import json
import glob
import os

spectator_check = {
    "type_specific": {
        "type": "minecraft:player",
        "gamemode": [
            "survival",
            "creative",
            "adventure"
        ]
    }
}

spectator_check_condition = {
      "condition": "minecraft:entity_properties",
      "entity": "this",
      "predicate": {
        "type_specific": {
          "type": "minecraft:player",
          "gamemode": [
            "survival",
            "adventure",
            "creative"
          ]
        }
      }
}

dir_path = os.path.dirname(os.path.realpath(__file__))
if os.name == 'posix':
    path = dir_path + "/*/*.json"
else:
    path = dir_path + "\*\*.json"
for advancement in glob.glob(path):
    with open(advancement, 'r') as file:
        data = json.load(file)

        if "display" in data and "announce_to_chat" in data["display"] and data["display"]["announce_to_chat"] is False:
            continue

        #if "conditions" in data["criteria"]:
        #    print(data["criteria"]["conditions"])
        #    print("\n")
        for i in data["criteria"]:
            if ("conditions" in data["criteria"][i]):
                if ("player" in data["criteria"][i]["conditions"]):
                    if ("type_specific" in data["criteria"][i]["conditions"]["player"]):
                        pass
                    else:
                        print(data["criteria"][i], (spectator_check["type_specific"]))
                        data["criteria"][i]["conditions"]["player"].append(spectator_check_condition)
                else:
                    data["criteria"][i]["conditions"]["player"] = spectator_check
            else:
                pass
                #print(data["criteria"][i]["conditions"]["player"]["type_specific"])


        #print(data)

                        #

        #data["criteria"][i]["conditions"]["player"]["type_specific"] += spectator_check
        if "display" in data and "frame" in data["display"]:
            tier = data["display"]["frame"]
        else:
            tier = "normal"

        if "rewards" not in data:
            data["rewards"] = {"function": f"roguecraft:skillpoints/advancement_{tier}"}
        else:
            data["rewards"]["function"] = f"roguecraft:skillpoints/advancement_{tier}"

        with open(advancement, 'w') as file:
            json.dump(data, file, indent=2)


'''


        '''