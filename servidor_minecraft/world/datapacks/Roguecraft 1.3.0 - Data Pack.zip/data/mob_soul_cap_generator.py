#import modules
import os

#get own directory
script_dir = os.path.dirname(__file__)

#define mob soul groups
mobs = [
    #lower
    [
        "allay",
        "armadillo",
        "axolotl",
        "bat",
        "bee",
        "cat",
        "chicken",
        "cod",
        "cow",
        "dolphin",
        "donkey",
        "fox",
        "frog",
        "glow_squid",
        "goat",
        "horse",
        "llama",
        "mule",
        "ocelot",
        "panda",
        "parrot",
        "pig",
        "polar_bear",
        "pufferfish",
        "rabbit",
        "salmon",
        "sheep",
        "snow_golem",
        "squid",
        "tadpole",
        "tropical_fish",
        "turtle",
        "wolf"
    ],
    
    #common
    [
        "camel",
        "cave_spider",
        "creeper",
        "drowned",
        "enderman",
        "endermite",
        "guardian",
        "husk",
        "magma_cube",
        "piglin",
        "pillager",
        "silverfish",
        "skeleton",
        "slime",
        "sniffer",
        "stray",
        "spider",
        "strider",
        "trader_llama",
        "villager",
        "wandering_trader",
        "zombie",
        "zombified_piglin"
    ],
    
    #higher
    [
        "blaze",
        "bogged",
        "breeze",
        "ghast",
        "hoglin",
        "iron_golem",
        "phantom",
        "shulker",
        "skeleton_horse",
        "vex",
        "vindicator",
        "witch",
        "wither_skeleton",
        "zoglin",
        "zombie_villager"
    ],
    
    #ascended
    [
        "elder_guardian",
        "evoker",
        "illusioner",
        "piglin_brute",
        "ravager",
        "warden",
        "wither"
    ],
]

#other values
level_max = [0,30,20,10]

#construct main loot table string
loot_table_base = '''
{
    "pools": 
    [
$(entries)
    ]
}
'''

mob_base = '''
        {
            "rolls": 1.0,
            "entries":
            [
                {
                    "type": "minecraft:loot_table",
                    "value": "roguecraft:mob_essence/$(level)_main"
                }
            ],
            "conditions": 
            [
                {
                    "condition": "minecraft:entity_properties",
                    "entity": "this",
                    "predicate": {
                        "type": "minecraft:$(type)"
                    }
                },
                {
                  "condition": "minecraft:value_check",
                  "value": {
                    "type": "minecraft:score",
                    "target": {
                      "type": "minecraft:fixed",
                      "name": "#roguecraft_master"
                    },
                    "score": "mob_essence_cap_$(type)"
                  },
                  "range": {
                    "max": $(max)
                  }
                }
            ]
        },
        {
            "rolls": 1.0,
            "entries":
            [
                {
                    "type": "minecraft:loot_table",
                    "value": "roguecraft:mob_essence/lower_main"
                }
            ],
            "conditions": 
            [
                {
                    "condition": "minecraft:entity_properties",
                    "entity": "this",
                    "predicate": {
                        "type": "minecraft:$(type)"
                    }
                },
                {
                  "condition": "minecraft:value_check",
                  "value": {
                    "type": "minecraft:score",
                    "target": {
                      "type": "minecraft:fixed",
                      "name": "#roguecraft_master"
                    },
                    "score": "mob_essence_cap_$(type)"
                  },
                  "range": {
                    "min": $(min)
                  }
                }
            ]
        }'''

entry_string = ""
loot_table_string = loot_table_base

#construct
for tier,list in enumerate(mobs):
    for mob in list:
        mob_string = mob_base
        mob_string = mob_string.replace("$(level)",["lower","common","higher","ascended"][tier]).replace("$(type)",mob).replace("$(max)",str(level_max[tier])).replace("$(min)",str(level_max[tier]+1))
        
        if (entry_string != ""):
            entry_string += ","
        
        entry_string += f"\n{mob_string}"

loot_table_string = loot_table_string.replace("$(entries)",entry_string)

#write to loot table
with open(os.path.join(script_dir,"roguecraft/loot_table/mob_essence/main_selector.json"),"w") as f:
    f.write(loot_table_string)
    
#define scores
base_score_name = "mob_essence_cap_"

with open(os.path.join(script_dir,"roguecraft/function/misc/mob_essence_cap/init.mcfunction"),"w") as f:
    for list in mobs:
        for mob in list:
            score_name = f"{base_score_name}{mob}"
            f.writelines(f"scoreboard objectives add {score_name} dummy\n")
            
with open(os.path.join(script_dir,"roguecraft/function/misc/mob_essence_cap/set.mcfunction"),"w") as f:  
    for list in mobs:
        for mob in list:
            score_name = f"{base_score_name}{mob}"
            f.writelines(f"scoreboard players set #roguecraft_master {score_name} 0\n")
            
#detect mob kill
advancement_base = '''{
    "criteria": {
      "mob": {
        "trigger": "minecraft:player_killed_entity",
        "conditions": {
          "entity": {
            "type": "minecraft:$(type)"
          }
        }
      }
    },
    "rewards": {
      "function": "roguecraft:misc/mob_essence_cap/mob_kill/$(type)"
    }
  }'''

for list in mobs:
    for mob in list:
        with open(os.path.join(script_dir,f"roguecraft/advancement/triggers/mob_kill/{mob}.json"),"w") as f:
            f.write(advancement_base.replace("$(type)",mob))
            
#add score on mob kill
command_base = '''
'''

for tier,list in enumerate(mobs):
    for mob in list:
        with open(os.path.join(script_dir,f"roguecraft/function/misc/mob_essence_cap/mob_kill/{mob}.mcfunction"),"w") as f:
            f.writelines(f"advancement revoke @s only roguecraft:triggers/mob_kill/{mob}\n\n")
            
            f.writelines(f"scoreboard players add #roguecraft_master mob_essence_cap_{mob} 1\n")
            f.writelines(f"execute unless score #roguecraft_master mob_essence_cap_{mob} matches {str(level_max[tier])} run return 0\n\n")
            f.writelines("execute as @a[tag=!hub,tag=!garden] at @s run playsound minecraft:entity.wither.ambient voice @s ~ ~ ~ 0.1 1\n")
            f.writelines(f"tellraw @a[tag=!hub,tag=!garden] {{\"translate\":\"roguecraft.chat_messages.mob_exhausted\",\"color\":\"dark_purple\",\"with\":[{{\"translate\":\"entity.minecraft.{mob}\"}}]}}\n\n")
            f.writelines(f"execute as @a[tag=!info_mob_exhausted] run function roguecraft:info_messages/mob_exhausted")